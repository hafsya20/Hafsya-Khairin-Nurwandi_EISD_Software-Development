﻿using System;
using System.Linq;

public class Soal1Input
{
    public static Tuple<double, double, double> AnalisisRating(double[] dataReview)
    {
        if (dataReview == null || dataReview.Length == 0)
        {
            return null;
        }

        double ratingTerendah = dataReview.Min();
        double ratingTertinggi = dataReview.Max();
        double rataRataRating = dataReview.Average();

        return Tuple.Create(ratingTerendah, ratingTertinggi, rataRataRating);
    }

    public static void Main(string[] args)
    {
        Console.WriteLine("Masukkan data review aplikasi (pisahkan dengan koma):");
        string inputString = Console.ReadLine();
        string[] ratingStrings = inputString.Split(',');
        double[] ratings = ratingStrings.Select(double.Parse).ToArray();

        var output = AnalisisRating(ratings);

        if (output != null)
        {
            Console.WriteLine($"Rating Terendah: {output.Item1}");
            Console.WriteLine($"Rating Tertinggi: {output.Item2}");
            Console.WriteLine($"Rata-rata Rating: {output.Item3}");
        }
        else
        {
            Console.WriteLine("Tidak ada data review yang dimasukkan.");
        }
    }
}