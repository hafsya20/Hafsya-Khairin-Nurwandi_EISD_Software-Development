﻿using System;
using System.Collections.Generic;
using System.Linq;

public class Soal9Input
{
    public static string UrutkanAnakNakal(List<string> daftarNama)
    {
        Dictionary<string, int> frekuensi = new Dictionary<string, int>();
        foreach (string nama in daftarNama)
        {
            frekuensi[nama] = frekuensi.ContainsKey(nama) ? frekuensi[nama] + 1 : 1;
        }

        // Filter nama-nama yang muncul lebih dari 2 kali (dianggap nakal)
        var anakNakalFrekuensi = frekuensi.Where(pair => pair.Value > 2);

        if (anakNakalFrekuensi.Count() == 0)
        {
            return "Semuanya anak baik";
        }
        else
        {
            // Urutkan anak nakal berdasarkan frekuensi (tertinggi ke terendah)
            var anakNakalUrut = anakNakalFrekuensi.OrderByDescending(pair => pair.Value).Select(pair => pair.Key).ToList();
            return string.Join(" ", anakNakalUrut) + " Nackal";
        }
    }

    public static void Main(string[] args)
    {
        Console.WriteLine("Masukkan nama-nama anak (pisahkan dengan koma):");
        string inputString = Console.ReadLine();
        List<string> namaAnak = inputString.Split(',').Select(s => s.Trim()).ToList();

        string hasilUrutan = UrutkanAnakNakal(namaAnak);
        Console.WriteLine($"Output: {hasilUrutan}");
    }
}