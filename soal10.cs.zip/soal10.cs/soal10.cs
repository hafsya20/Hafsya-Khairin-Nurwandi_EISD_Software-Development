﻿using System;
using System.Collections.Generic;
using System.Linq;

public class Soal10Input
{
    public static Dictionary<string, int> HitungKembalian(int totalPembayaran, int totalBelanja)
    {
        int kembalian = totalPembayaran - totalBelanja;
        if (kembalian < 0)
        {
            Console.WriteLine("Error: Pembayaran kurang!");
            return null;
        }

        int[] pecahan = { 100000, 50000, 20000, 10000, 5000, 2000, 1000, 500, 200, 100 };
        Dictionary<string, int> jumlahPecahan = new Dictionary<string, int>();
        int sisaKembalian = kembalian;

        foreach (int nilai in pecahan)
        {
            if (sisaKembalian >= nilai)
            {
                int jumlah = sisaKembalian / nilai;
                jumlahPecahan[nilai.ToString()] = jumlah;
                sisaKembalian %= nilai;
            }
        }

        return jumlahPecahan;
    }

    public static void Main(string[] args)
    {
        Console.WriteLine("Masukkan total pembayaran:");
        int pembayaran = int.Parse(Console.ReadLine());

        Console.WriteLine("Masukkan total belanja:");
        int belanja = int.Parse(Console.ReadLine());

        Dictionary<string, int> kembalian = HitungKembalian(pembayaran, belanja);

        if (kembalian != null)
        {
            Console.WriteLine("Kembalian:");
            // Urutkan dictionary berdasarkan kunci (nilai pecahan) dari terkecil ke terbesar
            var sortedKembalian = kembalian.OrderBy(kvp => int.Parse(kvp.Key));
            Console.WriteLine("{ " + string.Join(", ", sortedKembalian.Select(kvp => $"\"{kvp.Key}\": {kvp.Value}")) + " }");
        }
    }
}