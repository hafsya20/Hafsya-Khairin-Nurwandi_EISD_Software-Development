﻿using System;
using System.Collections.Generic;
using System.Linq;

public class Soal5Input
{
    public static int HitungKombinasiUsername(string namaLengkap, int panjangMaksimal)
    {
        string namaKecilGabung = new string(namaLengkap.ToLower().Where(c => !char.IsWhiteSpace(c)).ToArray());
        HashSet<string> jumlahKombinasi = new HashSet<string>();
        int n = namaKecilGabung.Length;

        for (int panjang = 1; panjang <= Math.Min(panjangMaksimal, n); panjang++)
        {
            Permutations(namaKecilGabung.ToCharArray(), 0, panjang, jumlahKombinasi);
        }

        return jumlahKombinasi.Count;
    }

    private static void Permutations(char[] elements, int k, int panjang, HashSet<string> hasil)
    {
        if (k == panjang)
        {
            hasil.Add(new string(elements.Take(panjang).ToArray()));
        }
        else
        {
            for (int i = k; i < elements.Length; i++)
            {
                Swap(ref elements[k], ref elements[i]);
                Permutations(elements, k + 1, panjang, hasil);
                Swap(ref elements[k], ref elements[i]); // backtrack
            }
        }
    }

    private static void Swap<T>(ref T a, ref T b)
    {
        (a, b) = (b, a);
    }

    public static void Main(string[] args)
    {
        Console.WriteLine("Masukkan nama lengkap:");
        string nama = Console.ReadLine();

        Console.WriteLine("Masukkan panjang maksimal username:");
        int panjangMax = int.Parse(Console.ReadLine());

        int jumlah = HitungKombinasiUsername(nama, panjangMax);
        Console.WriteLine($"Jumlah kombinasi username unik yang mungkin: {jumlah}");
    }
}