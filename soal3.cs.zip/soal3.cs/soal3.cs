﻿using System;
using System.Collections.Generic;
using System.Linq;

public class Soal3
{
    public static string DetektifKueV2(bool ningguangBertanya, bool fotoKueAda)
    {
        if (!ningguangBertanya)
        {
            if (fotoKueAda)
            {
                return "Hutao (karena tidak terlalu memperhatikan kue)";
            }
            else
            {
                return "Hutao atau Childe (karena Xiao tidak memotret dan Ningguang mungkin bertanya)";
            }
        }
        else
        {
            return "Kemungkinan bukan Ningguang (karena dia akan menyadari)";
        }
    }

    public static void Main(string[] args)
    {
        string pelakuV2 = DetektifKueV2(ningguangBertanya: false, fotoKueAda: true);
        Console.WriteLine($"Kesimpulan berdasarkan kebiasaan: {pelakuV2}");
    }
}