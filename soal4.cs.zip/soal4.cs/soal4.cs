﻿using System;
using System.Collections.Generic;
using System.Linq;

public class Soal4Input
{
    public static bool CekDuplikat(int[] data)
    {
        HashSet<int> seen = new HashSet<int>();
        foreach (int item in data)
        {
            if (seen.Contains(item))
            {
                return true;
            }
            seen.Add(item);
        }
        return false;
    }

    public static void Main(string[] args)
    {
        Console.WriteLine("Masukkan data angka (pisahkan dengan koma):");
        string inputString = Console.ReadLine();
        string[] angkaStrings = inputString.Split(',');
        int[] angka = angkaStrings.Select(int.Parse).ToArray();

        bool adaDuplikat = CekDuplikat(angka);
        Console.WriteLine($"Apakah ada duplikat? {adaDuplikat}");
    }
}