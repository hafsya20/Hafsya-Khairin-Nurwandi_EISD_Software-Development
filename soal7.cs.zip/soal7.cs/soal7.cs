﻿using System;
using System.Text;

public class Soal7Input
{
    public static string Decrypt(string ciphertext)
    {
        StringBuilder plaintext = new StringBuilder();
        foreach (char ch in ciphertext)
        {
            if (char.IsLetter(ch))
            {
                char baseChar = char.IsLower(ch) ? 'a' : 'A';
                int originalPos = ch - baseChar;
                int decryptedPos = (originalPos - 5 + 26) % 26; // Tambah 26 untuk menghindari negatif
                char decryptedChar = (char)(baseChar + decryptedPos);
                plaintext.Append(decryptedChar);
            }
            else
            {
                plaintext.Append(ch);
            }
        }
        return plaintext.ToString();
    }

    public static void Main(string[] args)
    {
        Console.WriteLine("Masukkan pesan yang ingin didekripsi:");
        string encryptedMessage = Console.ReadLine();

        string decryptedMessage = Decrypt(encryptedMessage);
        Console.WriteLine($"Pesan yang Didekripsi: {decryptedMessage}");
    }
}