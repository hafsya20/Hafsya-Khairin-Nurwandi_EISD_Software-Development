﻿using System;
using System.Linq;

public class Soal2Input
{
    public static bool CekPalindrom(string teks)
    {
        string teksBersih = new string(teks.ToLower().Where(char.IsLetterOrDigit).ToArray());
        string teksTerbalik = new string(teksBersih.Reverse().ToArray());
        return teksBersih.Equals(teksTerbalik);
    }

    public static void Main(string[] args)
    {
        Console.WriteLine("Masukkan kata atau kalimat untuk dicek palindrom:");
        string inputTeks = Console.ReadLine();

        bool isPalindrom = CekPalindrom(inputTeks);
        string output = isPalindrom ? "eureeka!" : "suka blyat";

        Console.WriteLine($"'{inputTeks}' -> {output}");
    }
}