﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

public class Soal6Input
{
    public static double HitungTotalBiaya(Dictionary<string, int> pesanan, Dictionary<string, Dictionary<string, object>> menu, double pajakMakanan, double pajakMinuman, double pajakTransaksi)
    {
        double subtotal = 0;
        foreach (var item in pesanan)
        {
            if (menu.ContainsKey(item.Key))
            {
                subtotal += (double)menu[item.Key]["Harga"] * item.Value;
            }
            else
            {
                Console.WriteLine($"Error: Item menu tidak ditemukan: {item.Key}");
                return -1; // Atau throw exception
            }
        }

        double totalPajak = 0;
        foreach (var item in pesanan)
        {
            if (menu.ContainsKey(item.Key))
            {
                string tipe = (string)menu[item.Key]["Tipe"];
                double hargaItem = (double)menu[item.Key]["Harga"];
                if (tipe == "Makanan")
                {
                    totalPajak += (hargaItem * pajakMakanan) * item.Value;
                }
                else if (tipe == "Minuman")
                {
                    totalPajak += (hargaItem * pajakMinuman) * item.Value;
                }
            }
        }

        double totalSetelahPajak = subtotal + totalPajak;
        double totalDenganPajakTransaksi = totalSetelahPajak * (1 + pajakTransaksi);

        return totalDenganPajakTransaksi;
    }

    public static void Main(string[] args)
    {
        Dictionary<string, Dictionary<string, object>> menuRestoran = new Dictionary<string, Dictionary<string, object>>()
        {
            {"Ayam Goreng Krispi", new Dictionary<string, object>() {{"Tipe", "Makanan"}, {"Harga", 15000.0}}},
            {"Ayam Puk Puk (Bukan di geprek)", new Dictionary<string, object>() {{"Tipe", "Makanan"}, {"Harga", 13000.0}}},
            {"Ayam Bakar", new Dictionary<string, object>() {{"Tipe", "Makanan"}, {"Harga", 20000.0}}},
            {"Es teh", new Dictionary<string, object>() {{"Tipe", "Minuman"}, {"Harga", 5000.0}}},
            {"Es Jeruk", new Dictionary<string, object>() {{"Tipe", "Minuman"}, {"Harga", 7000.0}}}
        };

        double pajakMakan = 0.05;
        double pajakMinum = 0.03;
        double pajakTransaksi = 0.15;

        Console.WriteLine("Masukkan pesanan (format: Nama Item,Jumlah - contoh: Ayam Bakar,2 - Es teh,1):");
        string inputPesanan = Console.ReadLine();
        string[] items = inputPesanan.Split('-');
        Dictionary<string, int> pesananPengguna = new Dictionary<string, int>();

        foreach (string item in items)
        {
            string[] detail = item.Trim().Split(',');
            if (detail.Length == 2 && menuRestoran.ContainsKey(detail[0].Trim()))
            {
                pesananPengguna[detail[0].Trim()] = int.Parse(detail[1].Trim());
            }
            else
            {
                Console.WriteLine($"Item tidak valid atau tidak ditemukan di menu: {item}");
            }
        }

        CultureInfo culture = new CultureInfo("id-ID");
        double totalBiaya = HitungTotalBiaya(pesananPengguna, menuRestoran, pajakMakan, pajakMinum, pajakTransaksi);

        if (totalBiaya > 0)
        {
            Console.WriteLine($"Total biaya pesanan Anda: Rp {totalBiaya.ToString("N0", culture)}");
        }
    }
}