﻿using System;
using System.Collections.Generic;
using System.Linq;

public class Soal8Input
{
    public static List<string> RekomendasiProduk(string namaPelanggan, Dictionary<string, Dictionary<string, List<string>>> dataPelanggan, Dictionary<string, Dictionary<string, object>> dataProduk)
    {
        if (!dataPelanggan.ContainsKey(namaPelanggan))
        {
            return new List<string>() { "Pelanggan tidak ditemukan." };
        }

        List<string> minatPelanggan = dataPelanggan[namaPelanggan]["Minat"];
        List<string> rekomendasi = new List<string>();

        foreach (var produkEntry in dataProduk)
        {
            string produk = produkEntry.Key;
            string kategori = (string)produkEntry.Value["Kategori"];

            if (minatPelanggan.Contains(kategori))
            {
                rekomendasi.Add(produk);
            }
        }

        return rekomendasi;
    }

    public static void Main(string[] args)
    {
        Dictionary<string, Dictionary<string, object>> produk = new Dictionary<string, Dictionary<string, object>>()
        {
            {"TV", new Dictionary<string, object>() {{"Kategori", "elektronik"}, {"Harga", 1000}}},
            {"headphone", new Dictionary<string, object>() {{"Kategori", "elektronik"}, {"Harga", 200}}},
            {"baju", new Dictionary<string, object>() {{"Kategori", "fashion"}, {"Harga", 50}}},
            {"gitar", new Dictionary<string, object>() {{"Kategori", "musik"}, {"Harga", 300}}},
            {"sepatu", new Dictionary<string, object>() {{"Kategori", "olahraga"}, {"Harga", 80}}},
            {"kamera", new Dictionary<string, object>() {{"Kategori", "elektronik"}, {"Harga", 600}}}
        };

        Dictionary<string, Dictionary<string, List<string>>> pelanggan = new Dictionary<string, Dictionary<string, List<string>>>()
        {
            {"Rina", new Dictionary<string, List<string>>() {{"Minat", new List<string>(){"elektronik", "musik"}}, {"Beli", new List<string>(){"TV", "headphone"}}}},
            {"Budi", new Dictionary<string, List<string>>() {{"Minat", new List<string>(){"fashion", "musik"}}, {"Beli", new List<string>(){"baju", "gitar"}}}},
            {"Hartono", new Dictionary<string, List<string>>() {{"Minat", new List<string>(){"olahraga", "elektronik"}}, {"Beli", new List<string>(){"sepatu", "kamera"}}}}
        };

        Console.WriteLine("Masukkan nama pelanggan:");
        string namaPelangganInput = Console.ReadLine();

        List<string> rekomendasi = RekomendasiProduk(namaPelangganInput, pelanggan, produk);
        Console.WriteLine($"Rekomendasi untuk {namaPelangganInput}: [\"{string.Join("\", \"", rekomendasi)}\"]");
    }
}